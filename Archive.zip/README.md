# naarmc2.github.io
Hi!

This is my first ever website. My plan was to make a cute website dedicated to the country I was born in. It's been very hard living away from my homeland and so the purpose of this website is really just to be a storage for my memories of my early childhood.